#coding=utf-8
import networkx as nx
import time
import matplotlib.pyplot as plt
aList = [1,1,2]
print aList

print len(aList)