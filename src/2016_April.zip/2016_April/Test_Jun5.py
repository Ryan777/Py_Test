#coding=utf-8
all_retweeters = [60482384, 16810856, 45311895, 14348934, 432390085, 65042895, 306216938, 144786053, 412904480]

unfound_users = set(all_retweeters)

print type(all_retweeters[0])
print type(unfound_users)