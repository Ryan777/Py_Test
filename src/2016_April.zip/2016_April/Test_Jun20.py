#coding=utf-8
with open('../data/test.txt','r') as f:
    text = f.read()