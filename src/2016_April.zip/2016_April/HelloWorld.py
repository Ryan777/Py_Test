a = [1,2,3]

b = [
    var
        for var in a
]

print(b)