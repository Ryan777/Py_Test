'''
Created on Jan 3, 2559 BE

@author: Rampage
'''
import tweepy
### 116501169@qq.com
consumer_key = '7FWpTHkeQMaO1bnHQYnd62De8'
consumer_secret = 'albUzEWdlrpI9gP8uH7FcCHi1Cgo2QLeKSPLPqNVIAUMimM2Fa'

access_token = '2668995974-UKVj9CIcCF0zfIeCBRvIyOGqL1oPPi6OJ1fH1y6'
access_secret = 'g7TgKKOJ0Bj1ua7UvGnWT98ztvmzVXA72OIcd04OCifZU'


###  rain.nevermore@gmail.com

consumer_key2 =	'BdbPzI6gPDserIB4mdT9gymX1'
consumer_secret2 = 'BNvkHR2nuXoYFtvbmtSOPcBqk29wSwoVriRbCx0XZllQjGkx4t'

access_token2 = '2669065116-x6TLDsT3us0zAb9hMUZVjvFITTPiQCrYDimmtlf'
access_secret2 = 'ZyJF6wkHlKxojsK8c6WCqtKpA167A5A1bp2hjC7ZnJfhj'

### www.ryan.777@hotmail.com
consumer_key3 =	'hj11IjbFiKv7cNhuDzC1AnPf5'
consumer_secret3 = '0QH0KqvMfJpAoOICdGsVzEQMTGUVAbfJMIiH9alZTCmLn2KFjp'

access_token3 = '738630462399086594-KL6X6u5VV2yVfYHA8Th3wXcnUShdh9x'
access_secret3 = 'axvctALrldJhD7x94hh1dkX36Fmqkudi4Xs4CxiWa0VMe'

### 27884969@qq.com
consumer_key4 =	'OwcDxs1T3gzfGgnGnvpocQBKC'
consumer_secret4 = '18yBeYZBizwp3BHXYL6etwKgq96BbYUT4trdnaeZD7SeEAbJ82'

access_token4 = '745806773907402752-ZXWYwjfeZJ2NOThgjG0mfhrti1nlarX'
access_secret4 = 'qoPENV5PuTEuN7UyRAX41WsCUlABEYeDl7YBs2PYRp4G5'

### 116501168@qq.com
consumer_key5 = 'qlieKHCnUErNIdA1IPElIbfvM'
consumer_secret5 = 'I1pkTAfCPi84WUZTkUkvmKa3C2kFjDEB2NIVFHXa3qhJxQ8QSA'

access_token5 = '745809241676513282-ElqgmtPmB8eZl1CMtKabWhbxJcBTS8M'
access_secret5 = 'KsUYKYtGrobaLHWyuuxiV8Fn0SakB2oabWrjmIIn5Qzny'

###   rain.nevermore@hotmail.com
consumer_key6 = '2TljfiHPwvEnvAIJBcxbVyTMQ'
consumer_secret6 = 'Y5Ea4royVD5FpjQvT0KlDlMEMZ78iBl1GOGFlEIgIEd2ovp2xB'

access_token6 = '745812351534804992-lLkXTsFNO5TCmhVn34HsdREUFj1sTwK'
access_secret6 = 'OrbdrzKE6oxniLrwGhdSN8wqtGHeDf7xLfISgslJvg7QH'

### www.ryan.777@gmail.com
consumer_key7 = 'wh3C2bhetsUhpAUn7HrZ2cWYk'
consumer_secret7 = 'BoaLWrfjIDQe5aWToytCZ99A3m2KpSnIhJw1L5V4IhPl2g49IS'

access_token7 = '745813631615401984-t2GoIhfwx2g7RQm4DD8AzYMFRp4iEMP'
access_secret7 = '02W2K5PKSxaGRvGiOeU8V3SKCNS1ErQIe48k5sxdfoNCX'



# import tweepy
# from local_config import *
# # Replace the API_KEY and API_SECRET with your application's key and secret.  ( consumer_key & consumer_secret )
# auth_app = tweepy.AppAuthHandler(consumer_key, consumer_secret)
# api_app = tweepy.API(auth_app, wait_on_rate_limit=True,wait_on_rate_limit_notify=True)
#


# import tweepy
# from local_config import *
# auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
# auth.set_access_token(access_token, access_secret)
# api = tweepy.API(auth,  wait_on_rate_limit=True,wait_on_rate_limit_notify=True)
