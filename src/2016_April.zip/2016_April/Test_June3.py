#coding=utf-8
from local_config import api_app as api


api.update_status("haha")
