#coding=utf-8
while True:

    print "haha"
    return False